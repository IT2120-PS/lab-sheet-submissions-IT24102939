setwd("C:\\Users\\umani\\Desktop\\IT24102939")
getwd()

#Question 01
#Part i
set.seed(123)   
time <- rnorm(25, mean = 45, sd = 2)
time


#Part ii
t.test(time, mu = 46, alternative = "less")


