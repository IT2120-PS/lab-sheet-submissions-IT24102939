setwd("C:\\Users\\umani\\Desktop\\IT24102939")
getwd()

#Q1

# Hypotheses
# H0 (Null): All four snack types are chosen with equal probability (pA = pB = pC = pD = 0.25)
# H1 (Alternative): At least one snack type is not equally likely (not all probabilities = 0.25)

#Q2

# Observed frequencies
observed <- c(120, 95, 85, 100)  
snack_types <- c("A", "B", "C", "D")

# Total observations
total <- sum(observed)

# Expected frequencies under equal probability
expected <- rep(total / length(observed), length(observed))

# Display observed vs expected
data.frame(Snack_Type = snack_types,
           Observed = observed,
           Expected = expected)

# Run chi-square goodness-of-fit test
chisq_test <- chisq.test(x = observed, p = rep(1/4, 4))

# Print test results
print(chisq_test)


#Q3

#  Conclusion
alpha <- 0.05  

cat("\nChi-square Statistic:", round(chisq_test$statistic, 3), "\n")
cat("Degrees of Freedom:", chisq_test$parameter, "\n")
cat("p-value:", round(chisq_test$p.value, 4), "\n\n")

if (chisq_test$p.value < alpha) {
  cat("Decision: Reject the null hypothesis (H0)\n")
  cat("Conclusion: There is significant evidence that customers do NOT choose all snack types equally.\n")
} else {
  cat("Decision: Fail to reject the null hypothesis (H0)\n")
  cat("Conclusion: There is no significant evidence against equal choice probabilities.\n")
}


